#!/bin/bash

# Check if MySQL Server is installed
if ! dpkg -l | grep -q mysql-server; then
    echo "MySQL Server is not installed. Installing..."
    apt-get update
    apt-get install -y mysql-server
else
    echo "MySQL Server is already installed."
fi

# Access MySQL and perform operations
mysql << EOF
ALTER USER 'root'@'localhost' IDENTIFIED BY 'password@009';
CREATE DATABASE IF NOT EXISTS wordpressdb;
CREATE USER 'wordpress'@'%' IDENTIFIED BY 'password@09';
GRANT ALL PRIVILEGES ON wordpressdb.* TO 'wordpress'@'%';
FLUSH PRIVILEGES;
EOF
